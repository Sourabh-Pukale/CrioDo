
curl -X POST localhost:8082/api/v1/auth/register -d '{"username": "crio.do", "password": "learnbydoing"}' -H 'Content-Type: application/json'
